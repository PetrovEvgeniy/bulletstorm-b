
// (c) Thorsten Hasbargen

import java.util.ArrayList;

final class A_GameObjectList extends ArrayList<A_GameObject> 
{ private static final long serialVersionUID = 1L;
}
